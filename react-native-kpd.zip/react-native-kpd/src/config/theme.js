import colors from './colors';

export default {
  colors,
};
