## React Native Elements website

https://react-native-elements.github.io/react-native-elements/

### Getting Started

The RNE website is made using [Docusaurus](https://docusaurus.io/). It's basically a React app with some magical markdown processor that helps make open source websites beautiful and maintainable.

- Install node_modules

```
yarn
```

- Start the react app

```
yarn start
```
